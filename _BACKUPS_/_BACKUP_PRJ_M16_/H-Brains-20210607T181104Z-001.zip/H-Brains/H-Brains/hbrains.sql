select*from alunos
order by Primeiro_Nome;


insert into alunos(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
  values('David','Silva','R.Alberto V da Broa Entrecampos','Lisboa');
insert into alunos(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values('Jose','Pedro','R.Combatentes da Grande Guerra Odivelas','Lisboa');
insert into alunos(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values('Joaquim','Carvalho','R.D Afonso IV Campo pequeno ','Lisboa');
insert into alunos(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values('Ana','Pereira','Av. Liberdade ','Lisboa')
insert into alunos (Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Jorge','Paulo','Rua Fernando Pessoa','Lisboa')
insert into alunos(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values('Miguel','Santos','R. Beatriz Angelo','Loures')
insert into alunos(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values('Madalena','Correia','Avenida D. Sebastiao','Loures')

select *
from alunos


select * from explicadores
order by Primeiro_Nome;

insert into explicadores(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Raul','Venancio',' Quinta do Outeiro Amadora','Lisboa')
insert into explicadores(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Vanessa','Martins','R. Almirante Reis','Lisboa')
insert into explicadores(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Paula','Horta','R. Dolores da Conceicao Bobadela','Loures')
insert into explicadores(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Susana','Sintra','Avenida das Dores ','Loures')
insert into explicadores(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Paulo','Sementinha','Rossio','Lisboa')
insert into explicadores(Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('Saul','Roberto','R.Santa Catarina','Lisboa')

select * from explicadores
delete  from explicadores

