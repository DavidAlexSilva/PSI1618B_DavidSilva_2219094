select * from explicadores
order by Primeiro_Nome
insert into explicadores(PessoaId,Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('913452432','Raul','Ven�ncio',' Quinta do Outeiro Amadora','Lisboa')
insert into explicadores(PessoaId,Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('913734324','Vanessa','Martins','R. Almirante Reis','Lisboa')
insert into explicadores(PessoaId,Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('914257321','Paula','Horta','R. Dolores da Concei��o Bobadela','Loures')
insert into explicadores(PessoaId,Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('913314525','Susana','Sintra','Avenida das Dores ','Loures')
insert into explicadores(PessoaId,Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('917342424','Paulo','Sementinha','Rossio','Lisboa')
insert into explicadores(PessoaId,Primeiro_Nome,Ultimo_Nome,Morada,Cidade)
values ('919813232','Sa�l','Roberto','R.Santa Catarina','Lisboa')
