﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_Brains
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click_1(object sender, EventArgs e)
        {
            new Form2().Show();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            new Form2().Show();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new Form4().Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            new Form5().Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            new Form6().Show();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            new Form7().Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            new Form8().Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            new Form9().Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            new Form10().Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new Form11().Show();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            new Form12().Show();
        }
    }
}
